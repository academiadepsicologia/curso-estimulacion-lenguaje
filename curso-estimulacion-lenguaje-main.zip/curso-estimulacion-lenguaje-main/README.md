# curso-estimulacion-lenguaje
Curso para padres de niños de 3 a 5 años sobre estimulación del lenguaje en casa
